setwd("C:/Users/HP/OneDrive/Desktop/IT24102225")

# (i)
baking_times <- rnorm(25, mean=45, sd=2)
baking_times

#(ii)
t.test(baking_times, mu=46, alternative="less")
res <- t.test(baking_times, mu=46, alternative="less")
res$statistic  
res$p.value    
res$conf.int   