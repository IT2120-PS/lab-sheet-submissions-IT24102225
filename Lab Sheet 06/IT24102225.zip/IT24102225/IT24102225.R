# Question 1
# Part i
n <- 50
p <- 0.85
cat("Question 1(i): The distribution of X is Binomial with n =", n, "and p =", p, "\n")

# Part ii
prob_q1ii <- pbinom(46, size = n, prob = p, lower.tail = FALSE)  # P(X >= 47) = 1 - P(X <= 46)
cat("Question 1(ii): Probability that at least 47 students passed:", prob_q1ii, "\n")

# Question 2
# Part i: Random variable X
cat("Question 2(i): The random variable X is the number of customer calls received in an hour\n")

# Part ii
lambda <- 12
cat("Question 2(ii): The distribution of X is Poisson with lambda =", lambda, "\n")

# Part iii
prob_q2iii <- dpois(15, lambda = lambda)
cat("Question 2(iii): Probability of exactly 15 calls in an hour:", prob_q2iii, "\n")